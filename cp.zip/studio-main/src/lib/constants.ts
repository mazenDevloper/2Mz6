export const AI_ASSISTANT_API_KEY = 'AIzaSyBMmtON9ww4dJxMHrl1wKyWTvI0ipJXJws'; 
export const WEATHER_API_KEY = '7acefc26deee4904a2393917252207'; 
export const GOOGLE_MAPS_API_KEY = 'AIzaSyBRqAHJ2elbE_Z7NXXYC50XZpqi6HbG6Rk';
export const FOOTBALL_API_KEY = '5faa81bde7c1843d6be4a4e3706a93da'; 
export const FOOTBALL_API_BASE_URL = 'https://v3.football.api-sports.io';

export const YT_KEYS_POOL = [
    "AIzaSyCcB-bW1b1bSu3hzROVhSbRT-D894zHYeg", // المفتاح الموفر الجديد
    "AIzaSyCtgdzDMCpCbGe1vSAu0F4wBKERC77ac6I",
    "AIzaSyAjdVZ2Rodp6ZVEF1pZT195kAtGELolxSI",
    "AIzaSyDULoFJLWNIO9hn0u8siLz-BzTi7eM-CX4",
    "AIzaSyBYThRM6tVnzgFgdHOUAN6DN8jQd54OKeg"
];

export const prayerTimesData = [
    {"date":"2026-02-01","day":"الأحد","fajr":"05:41","sunrise":"06:55","dhuhr":"12:42","asr":"15:59","maghrib":"18:24","isha":"19:34"},
    {"date":"2026-02-02","day":"الاثنين","fajr":"05:41","sunrise":"06:55","dhuhr":"12:42","asr":"15:59","maghrib":"18:25","isha":"19:34"},
    {"date":"2026-02-03","day":"الثلاثاء","fajr":"05:40","sunrise":"06:55","dhuhr":"12:42","asr":"15:59","maghrib":"18:25","isha":"19:34"},
    {"date":"2026-02-04","day":"الأربعاء","fajr":"05:40","sunrise":"06:54","dhuhr":"12:43","asr":"16:00","maghrib":"18:26","isha":"19:35"},
    {"date":"2026-02-05","day":"الخميس","fajr":"05:40","sunrise":"06:54","dhuhr":"12:43","asr":"16:00","maghrib":"18:26","isha":"19:35"},
    {"date":"2026-02-06","day":"الجمعة","fajr":"05:40","sunrise":"06:54","dhuhr":"12:43","asr":"16:00","maghrib":"18:27","isha":"19:36"},
    {"date":"2026-02-07","day":"السبت","fajr":"05:40","sunrise":"06:53","dhuhr":"12:43","asr":"16:01","maghrib":"18:27","isha":"19:36"},
    {"date":"2026-02-08","day":"الأحد","fajr":"05:39","sunrise":"06:53","dhuhr":"12:43","asr":"16:01","maghrib":"18:28","isha":"19:36"},
    {"date":"2026-02-09","day":"الاثنين","fajr":"05:39","sunrise":"06:53","dhuhr":"12:43","asr":"16:01","maghrib":"18:28","isha":"19:37"},
    {"date":"2026-02-10","day":"الثلاثاء","fajr":"05:39","sunrise":"06:52","dhuhr":"12:43","asr":"16:01","maghrib":"18:28","isha":"19:37"},
    {"date":"2026-02-11","day":"الأربعاء","fajr":"05:38","sunrise":"06:52","dhuhr":"12:43","asr":"16:01","maghrib":"18:29","isha":"19:37"},
    {"date":"2026-02-12","day":"الخميس","fajr":"05:38","sunrise":"06:51","dhuhr":"12:43","asr":"16:02","maghrib":"18:29","isha":"19:38"},
    {"date":"2026-02-13","day":"الجمعة","fajr":"05:38","sunrise":"06:51","dhuhr":"12:43","asr":"16:02","maghrib":"18:30","isha":"19:38"},
    {"date":"2026-02-14","day":"السبت","fajr":"05:37","sunrise":"06:51","dhuhr":"12:43","asr":"16:02","maghrib":"18:30","isha":"19:38"},
    {"date":"2026-02-15","day":"الأحد","fajr":"05:37","sunrise":"06:50","dhuhr":"12:43","asr":"16:02","maghrib":"18:30","isha":"19:39"},
    {"date":"2026-02-16","day":"الاثنين","fajr":"05:37","sunrise":"06:50","dhuhr":"12:43","asr":"16:02","maghrib":"18:31","isha":"19:39"},
    {"date":"2026-02-17","day":"الثلاثاء","fajr":"05:36","sunrise":"06:49","dhuhr":"12:43","asr":"16:02","maghrib":"18:31","isha":"19:39"},
    {"date":"2026-02-18","day":"الأربعاء","fajr":"05:36","sunrise":"06:49","dhuhr":"12:43","asr":"16:03","maghrib":"18:32","isha":"19:40"},
    {"date":"2026-02-19","day":"الخميس","fajr":"05:35","sunrise":"06:48","dhuhr":"12:43","asr":"16:03","maghrib":"18:32","isha":"19:40"},
    {"date":"2026-02-20","day":"الجمعة","fajr":"05:35","sunrise":"06:48","dhuhr":"12:42","asr":"16:03","maghrib":"18:32","isha":"19:40"},
    {"date":"2026-02-21","day":"السبت","fajr":"05:34","sunrise":"06:47","dhuhr":"12:42","asr":"16:03","maghrib":"18:33","isha":"19:40"},
    {"date":"2026-02-22","day":"الأحد","fajr":"05:34","sunrise":"06:46","dhuhr":"12:42","asr":"16:03","maghrib":"18:33","isha":"19:41"},
    {"date":"2026-02-23","day":"الاثنين","fajr":"05:33","sunrise":"06:46","dhuhr":"12:42","asr":"16:03","maghrib":"18:33","isha":"19:41"},
    {"date":"2026-02-24","day":"الثلاثاء","fajr":"05:33","sunrise":"06:45","dhuhr":"12:42","asr":"16:03","maghrib":"18:34","isha":"19:41"},
    {"date":"2026-02-25","day":"الأربعاء","fajr":"05:32","sunrise":"06:45","dhuhr":"12:42","asr":"16:03","maghrib":"18:34","isha":"19:41"},
    {"date":"2026-02-26","day":"الخميس","fajr":"05:32","sunrise":"06:44","dhuhr":"12:42","asr":"16:03","maghrib":"18:34","isha":"19:42"},
    {"date":"2026-02-27","day":"الجمعة","fajr":"05:31","sunrise":"06:43","dhuhr":"12:41","asr":"16:03","maghrib":"18:35","isha":"19:42"}
];

export function convertTo12Hour(time24h: string | undefined): string {
    if (!time24h || typeof time24h !== 'string' || time24h === '--:--') {
        return time24h || '--:--';
    }
    const [hours24, minutes] = time24h.split(':').map(str => parseInt(str, 10));
    let hours12 = hours24 % 12;
    hours12 = hours12 ? hours12 : 12;
    return `${hours12}:${minutes.toString().padStart(2, '0')}`;
}
